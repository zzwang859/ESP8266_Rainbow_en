#ifndef _CAIYUN_H_
#define _CAIYUN_H_
 
#include <Arduino.h>
#include <ArduinoJson.h>
#include <ESP8266WiFi.h>

#define DEBUG   // 调试用宏定义

// 获取天气预报信息类
class Caiyun {
  public:
    Caiyun();

    void config(String userKey, double longitude, double latitude);
    bool update();

    String getDayText();           /* 获取白天天气(字符串)   */
    int getDayCode();              /* 获取白天天气(数字代码) */
    String getNightText();         /* 获取晚上天气(字符串)   */
    int getNightCode();            /* 获取晚上天气(数字代码) */
    int getHigh();                 /* 获取最高温度          */
    int getLow();                  /* 获取最低温度          */
       
    int getTimeZone();             /* 获取时区            */
    unsigned long getServerTime(); /* 获取服务器时间       */
    unsigned long getLocalTime();  /* 获取本时区时间       */
    String getServerCode();        /* 获取服务器响应状态码 */

  private:  
    const char* _host = "api.caiyunapp.com";     // 服务器地址 

    String   _reqUserKey ;         // 彩云天气私钥
    double _longitude = -74.0060;  // 经度（示例：北京）
    double _latitude  =  40.7128;  // 纬度  

    String _response_code =  "no_init";   // 服务器响应状bool态码 
    
    int _tzshift     = 0;                 /* 时区偏移    */
    unsigned long _server_time = 0;       /* 服务器时间  Unix时间戳(UTC=0) */


    String  _text_day =  {"no_init no_init no_init no_init"};  // 白天天气(字符串)
    int _code_day   = 999;                                     // 白天天气(索引)
    String _text_night = {"no_init no_init no_init no_init"};  // 晚上天气（字符串）
    int _code_night = 999;                                     // 晚上天气（索引）

    int _degree_high = 0;     // 最高气温
    int _degree_low  = 0;      // 最低气温

    bool _parseForecastInfo(WiFiClient client);      // 解析天气信息信息
    int _remapWeatherIcon(const char* skycon);       // 天气现象转换为代码
    
};
#endif
