#include "Caiyun.h"

Caiyun::Caiyun(){
}

/* 配置彩云天气请求信息
 * @param userKey  用户彩云天气私钥
 * @param longitude 经度
 * @param latitude  纬度
 */
void Caiyun::config(String userKey, double longitude, double latitude){
  _reqUserKey = userKey; 
  _longitude  = longitude;  // 经度（示例：北京）
  _latitude   = latitude;    // 纬度  
}

/**************************************************************************************************************************/
/* 尝试从彩云天气更新天气预报信息
  @return: bool 成功更新返回真，否则返回假 */
/**************************************************************************************************************************/
bool Caiyun::update()
{
  WiFiClient _wifiClient;
  
  /********** 彩云天气访问方式 *****************/
  String reqRes = "/v2.6/" + _reqUserKey + "/" +
                 String(_longitude,6)  + "," + 
                 String(_latitude, 6) + 
                 "/daily?dailysteps=1&lang=en_US";   

  String httpRequest = String("GET ") + reqRes + " HTTP/1.1\r\n" + 
                              "Host: " + _host + "\r\n" + 
                              "Connection: close\r\n\r\n";                            
                              
  #ifdef DEBUG
  Serial.print("Connecting to ");Serial.print(_host);
  #endif DEBUG 

  if (_wifiClient.connect(_host, 80)){

    #ifdef DEBUG
    Serial.println(" Success!");
    #endif DEBUG   

    // 向服务器发送http请求信息
    _wifiClient.print(httpRequest);
    
    #ifdef DEBUG
    Serial.println("Sending request: ");
    Serial.println(httpRequest);
    #endif DEBUG  

    // 等待服务器响应
    unsigned long timeout = millis();
    while (_wifiClient.available() == 0) {
      #ifdef DEBUG
      Serial.print(".");
      #endif DEBUG 
      delay(100);
      if (millis() - timeout > 5000) {
        #ifdef DEBUG
        Serial.println(">>> Client Timeout !");
        #endif DEBUG 
        _wifiClient.stop();
        return false;
      }
    }      
 
    // 获取并显示服务器响应状态行 
    String _status_response = _wifiClient.readStringUntil('\n');

    #ifdef DEBUG
    Serial.print("_status_response: ");
    Serial.println(_status_response);
    #endif DEBUG 

    
    // 查验服务器是否响应200 OK
    _response_code = _status_response.substring(9, 12);
    if (_response_code == "200") {
      #ifdef DEBUG
      Serial.println("Response Code: 200");
      #endif DEBUG 
        
    } else {
      #ifdef DEBUG
      Serial.println(F("Response Code: NOT 200"));
      #endif DEBUG     
      _wifiClient.stop();    

    }  

    // 使用find跳过HTTP响应头
    if (_wifiClient.find("\r\n\r\n")) {
      #ifdef DEBUG
      Serial.println("Found Header End. Start Parsing."); 
      #endif DEBUG       
    }

    // // 解析服务器响应信息
    if( _parseForecastInfo(_wifiClient)){
    } else {
      return false;  /* 解析失败 */
    }
    _wifiClient.stop();
    return true;
  } else {

    #ifdef DEBUG   
    Serial.println(" connection failed!");  
    #endif DEBUG  
    _wifiClient.stop();
    return false;
  }                           
}                         

/**************************************************************************************************************************/
// 解析服务器响应信息
/**************************************************************************************************************************/
bool Caiyun::_parseForecastInfo(WiFiClient httpClient)
{
    const size_t capacity = JSON_ARRAY_SIZE(1) + JSON_ARRAY_SIZE(3) + 
                            JSON_OBJECT_SIZE(1) + JSON_OBJECT_SIZE(3) + 
                            JSON_OBJECT_SIZE(6) + 3*JSON_OBJECT_SIZE(14) + 3200;              /* 解析存储空间 */

    DynamicJsonDocument doc(capacity);
    DeserializationError error = deserializeJson(doc, httpClient);

    if (error) {
      #ifdef DEBUG 
      Serial.print("deserializeJson() failed: ");
      Serial.println(error.c_str());
      #endif DEBUG  

      return false;
    }


     _tzshift     = doc["tzshift"].as<int>();                                                  /* 时区偏移           */
     _server_time = doc["server_time"].as<int>();                                              /* 服务器时间         */

    _text_day    = doc["result"]["daily"]["skycon_08h_20h"][0]["value"].as<String>();          /* 白天天气现象字符串  */
    _text_night  = doc["result"]["daily"]["skycon_20h_32h"][0]["value"].as<String>();          /* 夜晚天气现象字符串  */
    _degree_high = doc["result"]["daily"]["temperature"][0]["max"].as<int>();                  /* 最高气温           */
    _degree_low  = doc["result"]["daily"]["temperature"][0]["min"].as<int>();                  /* 最低气温           */
    _code_day    = _remapWeatherIcon(_text_day.c_str()) ;                                      /* 白天天气现象索引    */
    _code_night  = _remapWeatherIcon(_text_night.c_str()) ;                                    /* 夜晚天气现象索引    */

    doc.clear();

    #ifdef DEBUG 
    Serial.printf("        _tzshift:%d\r\n", _tzshift);
    Serial.printf("     server_time:%d\r\n", _server_time);
    Serial.printf("        DAY_CODE:%02d--", _code_day);     Serial.println(_text_day);
    Serial.printf("      NIGHT_CODE:%02d--", _code_night);   Serial.println(_text_night);
    Serial.printf("temperature_High:%d\r\n", _degree_high);
    Serial.printf("temperature_low :%d\r\n", _degree_low);
    #endif DEBUG 

    return true;
}

/**************************************************************************************************************************/
// 将天气现象字符串转换为 数字代码
/**************************************************************************************************************************/
int  Caiyun::_remapWeatherIcon(const char* skycon) {
    if(strcmp(skycon, "CLEAR_DAY")           == 0){return 0;}  /*晴（白天）  */
    if(strcmp(skycon, "CLEAR_NIGHT")         == 0){return 1;}  /*晴（夜间）  */
    if(strcmp(skycon, "PARTLY_CLOUDY_DAY")   == 0){return 5;}  /*多云（白天）*/
    if(strcmp(skycon, "PARTLY_CLOUDY_NIGHT") == 0){return 6;}  /*多云（夜间）*/
    if(strcmp(skycon, "CLOUDY")              == 0){return 9;}  /*阴          */
    if(strcmp(skycon, "LIGHT_HAZE")          == 0){return 31;} /*轻度雾霾    */
    if(strcmp(skycon, "MODERATE_HAZE")       == 0){return 31;} /*中度雾霾    */
    if(strcmp(skycon, "HEAVY_HAZE")          == 0){return 31;} /*重度雾霾    */
    if(strcmp(skycon, "LIGHT_RAIN")          == 0){return 13;} /*小雨        */
    if(strcmp(skycon, "MODERATE_RAIN")       == 0){return 14;} /*中雨        */
    if(strcmp(skycon, "HEAVY_RAIN")          == 0){return 15;} /*大雨        */
    if(strcmp(skycon, "STORM_RAIN")          == 0){return 16;} /*暴雨        */
    if(strcmp(skycon, "FOG")                 == 0){return 30;} /*雾          */
    if(strcmp(skycon, "LIGHT_SNOW")          == 0){return 22;} /*小雪        */
    if(strcmp(skycon, "MODERATE_SNOW")       == 0){return 23;} /*中雪        */
    if(strcmp(skycon, "HEAVY_SNOW")          == 0){return 24;} /*大雪        */
    if(strcmp(skycon, "STORM_SNOW")          == 0){return 25;} /*暴雪        */
    if(strcmp(skycon, "DUST")                == 0){return 26;} /*浮尘        */
    if(strcmp(skycon, "SAND")                == 0){return 27;} /*沙尘        */
    if(strcmp(skycon, "WIND")                == 0){return 33;} /*大风        */
    return 999;                                                 /* 返回未知天气 N/A */
}

// 返回白天天气（字符串格式）
String Caiyun::getDayText(){
  return _text_day;
}

// 返回白天天气（整数格式）
int Caiyun::getDayCode(){
  return _code_day;
}

// 返回夜晚天气（字符串格式）
String Caiyun::getNightText(){
  return _text_night;
}

// 返回夜晚天气（整数格式）
int Caiyun::getNightCode(){
  return _code_night;
}

// 返回最高气温
int Caiyun::getHigh(){
  return _degree_high;
}

// 返回最低气温
int Caiyun::getLow(){
  return _degree_low;
}

// 返回时区
int Caiyun::getTimeZone(){
  return _tzshift;
}

// 返回服务器时间
unsigned long Caiyun::getServerTime(){
  return _server_time;
}

// 返回本时区时间
unsigned long Caiyun::getLocalTime(){
  return _server_time+_tzshift;
}

// 返回服务器响应状态码
String Caiyun::getServerCode(){
  return _response_code;
}
